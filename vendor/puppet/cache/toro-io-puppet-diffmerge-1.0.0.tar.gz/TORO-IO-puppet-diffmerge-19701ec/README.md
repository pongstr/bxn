# Diffmerge Puppet Module for Boxen

## Usage

```puppet
include diffmerge
```

## Required Puppet Modules

* boxen

