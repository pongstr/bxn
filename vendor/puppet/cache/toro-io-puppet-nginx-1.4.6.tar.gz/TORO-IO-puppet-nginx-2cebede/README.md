# nginx Puppet Module for Boxen
[![Build
Status](https://travis-ci.org/boxen/puppet-nginx.png?branch=master)](https://travis-ci.org/boxen/puppet-nginx)

## Usage

```puppet
include nginx
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
