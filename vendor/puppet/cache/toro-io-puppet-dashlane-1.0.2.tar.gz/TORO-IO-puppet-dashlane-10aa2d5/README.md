# Dashlane Puppet Module for Boxen

[![Build Status](https://travis-ci.org/hkaju/puppet-dashlane.png?branch=master)](https://travis-ci.org/hkaju/puppet-dashlane)

## Usage

```puppet
include dashlane
```

## Required Puppet Modules

* boxen

